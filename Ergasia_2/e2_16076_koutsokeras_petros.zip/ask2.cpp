#include <iostream>
#include <string>
#include <sstream>
#include <list>
#include <fstream>
using namespace std;

/* Struct for Double Linked list */
struct node{
    string code;
    string name;
    int year;
    string direction;
    double grade;
    int data;
    struct node* next;
    struct node* prev;
};

/* Insert node at front  */
void insert_front(struct node** head, int new_data){
    struct node* newnode= new node;
    newnode -> data = new_data; //data assign
    newnode ->next = (*head);
    newnode -> prev = NULL;

    if((*head) != NULL){
        (*head) -> prev = newnode;
    }
    (*head)=newnode;
}

/* Insert Node at Back */
void insert_back(struct node** head,int new_data){

    struct node* newnode = new node;
    struct node* last = *head;
    newnode -> data = new_data;
    newnode -> next = NULL; 

    if(*head == NULL){
        newnode -> prev = NULL;
        *head = newnode;
        return;
    }
}

/* Erase node*/
void erase (struct node** head,node* del){

    if(*head == NULL || del == NULL){
        return;
    }

    if(*head == del){
        *head = del -> next;
    }

    if(del -> next !=NULL){
        del -> next -> prev = del -> prev;
    }

    if(del-> prev !=NULL){
        del -> prev -> next = del -> next;
    }
}

/* Print node */
void print_forward(node* node){
    while(node !=NULL){
        cout << "Code :" << node->code << "Name:" << node -> name << "Year :" << node -> year << "Direction : " << node -> direction << "Grade : " << node -> grade << endl; 
        node = node -> next;
    }
}

/* Print node at reverse */
void print_reverse(struct node** head){
    struct node* node= *head;

    while(node -> next !=NULL){
        node = node -> next;
    }

    while(node != *head){
        cout << node -> data << " ";
    }

   cout << "Code : " << node->code << "Name : " << node -> name << "Year :" << node -> year << "Direction" << node -> direction << "Grade : " << node -> grade << endl; 
}
int main(){
    struct node *head;
   list<node>a_list;
   fstream fin;
   /* Read the File Line by line */
   fin.open("students.txt",ios::in);
   string line;
   while(getline(fin,line)){
       stringstream ss(line);
       node a_student;  
    ss >> a_student.code;
    ss >> a_student.name;
    ss >> a_student.year;
    ss >> a_student.direction;
    ss >> a_student.grade;
     print_forward(&a_student);
    a_list.push_back(a_student);
}
     system("pause");
}
